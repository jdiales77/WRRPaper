rm(list = ls())
setwd("/Users/johndialesandro/Desktop/ENVS110")
library(readr)
library(dplyr)
library(ggplot2)
library(mosaic)
library(car)
birth <- read.csv('birthwt.csv')
data <-read.csv('GAMA_Nitrate_VWC_Reduced.csv')


data$DroughtYear <-ifelse(data$Drought =="ND", "No Drought", 
                          ifelse(data$Drought =="SD", "Severe Drought", 
                                 ifelse(data$Drought=="MD", "Moderate Drought", 
                                        "other")))
ANOVA <-aov(results~DroughtYear, data = data)
summary(ANOVA)
tukey_output <- TukeyHSD(ANOVA)  #performs the test
tukey_output
Df <- summarise(group_by(data,  DroughtYear), meanNitrate = mean(results),
                seN= sd(results/sqrt(n())))

ggplot(Df)+geom_col(aes(x= reorder(DroughtYear, -meanNitrate), y =meanNitrate, width =0.4, fill = "#C4A484")) +
  theme_minimal()+
  theme(axis.text=element_text(size=12))+
  geom_errorbar(aes(x= DroughtYear, ymin=meanNitrate-seN, ymax=meanNitrate+seN),
                width=0.1)+
  scale_fill_manual(values=c("#C4A484"))+
  labs(title="Mean Annual Nitrate Values by Year Drought 
       Classifciation (2000-2023)",
       x="Drought Year Classification", y = "Well Nitrate Level (mg/l)")+ 
  annotate("text", 1, 11, label ="*No Drought")+
  geom_hline(yintercept=10, 
             linetype= "dotted", color = "red", size =1, show.legend = FALSE)+
  annotate("text", x=3.1, y=10.5, label=".         MCL")

ggplot(Df)+geom_col(aes(x= Smk_stat, y =meanW, width =0.4)) +theme_classic()+
  geom_errorbar(aes(x= Smk_stat, ymin=meanW-seW, ymax=meanW+seW),
                width=0.1)+
  labs(title="Birth weight by smoking status",
       x="Smoking status", y = "Birth weight (lbs)")+ annotate("text", 3, 8, label ="a")+ annotate("text", 4, 8, label ="a")



head(data)
Trees <-read.csv("Fresno_DataShadeandTrees.csv")
Trees <-subset(Trees, dac_status != "No Data Available")
Trees$shadestatus <-ifelse(Trees$Shade >20, "good",
                     ifelse(Trees$Shade <20, "bad", "other"))
Trees$status <-ifelse(Trees$dac_status == "Not a Disadvantaged Community", "No",
                     ifelse(Trees$dac_status=="Disadvantaged Community" | 
                     Trees$dac_status =="Severely Disadvantaged Community", "
                            Yes", "other"))
Data <-read.csv("Fresno_DataShadeandTreesLST.csv")
Data <-subset(Data, dac_status != "No Data Available")

Data$LatN <-ifelse(Data$hislat_per >= 0.4833719, "high", 
                   ifelse(Data$hislat_per < 0.4833719, "low", "other"))
t.test(data= Data, Shade~ LatN)
Data$status <-ifelse(Data$dac_status == "Not a Disadvantaged Community", "Not Disadvantaged",
                      ifelse(Data$dac_status=="Disadvantaged Community" | 
                               Data$dac_status =="Severely Disadvantaged Community", "Disadvantaged", "other"))

Dis <-subset(Data, status == "Disadvantaged")
Data <-subset(Data, MEAN_1 >= 0.1)
Df <-summarise(group_by(Data,  status), meanLST = mean(MEAN_1),
                        meanPTC = mean(PTC), meanShade =mean(Shade), Count =n())
ggplot(Data, aes(x = mhhi, y = MEAN_1, fill = status))+geom_point() +theme_classic()+
  geom_point(size=2, color="blue", shape=23)+
  labs(title="Mean Radiant Temperature vs Income 
       by Blockgroup",
       x="Median Income ($)", y = "MRT (C)")+
  geom_smooth(method=lm, se=FALSE)
modelincome<- lm(mhhi~MEAN_1, data =data)
ANOVA <-aov(Shade~dac_status, data = Data)
summary(ANOVA)
tukey_output <- TukeyHSD(ANOVA)  #performs the test

tukey_output

summary <- summarise(group_by(Trees, status),count = n())

obs<-Trees %>%
  group_by(status, shadestatus) %>%
  summarise(sum_cases=n())

ggplot(obs, aes(x=status, y=sum_cases, fill=shadestatus))+theme_classic()+
  ylim(0, 300)+
  labs(title="Ears cleared by treatment ",
       x="Antibitoic Treatment", y = "Count")+ geom_col(position = "dodge")+ 
  scale_fill_manual(values=c(cleared = "blue", uncleared = "purple"))


ear.matrix <- xtabs(sum_cases ~ status + shadestatus, data = obs)
ear.matrix
results <- chisq.test(ear.matrix)
results
#make a graph
ggplot(birth, aes(x = Smk_stat, y = Birthwt))+geom_boxplot()+theme_classic()
ggplot(Data, aes(x = status, y = MEAN_1))+geom_boxplot()+theme_classic()
#check assumptions 
ggplot(birth, aes(x = Birthwt))+ geom_histogram(bins = 8)+ facet_wrap(~ Smk_stat, ncol = 2)

#test for normality
tapply(birth$Birthwt, birth$Smk_stat, shapiro.test)

#use as facto
birth$Smk_stat <- as.factor(birth$Smk_stat)

#levene test
leveneTest(Birthwt ~ Smk_stat, data= birth)

#run the anova test 
#step 1 calculate the sums of squares 
ANOVA <-aov(results~Drought, data = data)
ANOVA <- aov(Birthwt ~ Smk_stat, data = birth)
ANOVA <-aov(MEAN_1~dac_status, data = Data)
#summarize
summary(ANOVA)

#perform post hoc tests 
tukey_output <- TukeyHSD(ANOVA)  #performs the test

tukey_output #execute this to display results in the console

modelA <- lm(Shade ~ mhhi, data= Trees)
summary(modelA)
plot(modelA)
#make a graphic 
Df <- summarise(group_by(Data,  dac_status), meanW = mean(MEAN_1),
                seW = sd(MEAN_1/sqrt(n())))

ggplot(Df)+geom_col(aes(x= dac_status, y =meanW, width =0.4)) +theme_classic()+
  geom_errorbar(aes(x= dac_status, ymin=meanW-seW, ymax=meanW+seW),
                width=0.1)+
  labs(title="Birth weight by smoking status",
       x="Smoking status", y = "Birth weight (lbs)")+ annotate("text", 3, 8, label ="a")+ annotate("text", 4, 8, label ="a")


#decile 
quantile(Data$mhhi, probs = seq(.1, .9, by = .1))
quantile(Data$Shade, probs = seq(.1, .9, by = .1))
Highshade <- subset(Data, Shade >= 24.57)
Lowshade <-subset(Data, Shade <= 11.38)
mean(Highshade$MEAN_1)
mean(Lowshade$MEAN_1)
mean(Highshade$mhhi)
mean(Lowshade$mhhi)
cor

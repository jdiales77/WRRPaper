install.packages("tidyverse")
install.packages("Kendall")
install.packages("trend")


library(trend)
library(tidyverse)
library(Kendall)
Data <-read.csv("Modesto_2010_Wells.csv")
Data <-aggregate(Data, GM_RESULT~CONCAT_WEL+GM_LATITUD +GM_LONGITU, mean)
Data <-aggregate(Data, GM_RESULT~CONCAT_WEL+GM_LATITUD +GM_LONGITU+DEPTH_ZONE, mean)
write.csv(Data, "ModestoInterpolationvAllZones.csv")
DataT <-read.csv("Turlock_2010_Wells.csv")
DataT <-aggregate(DataT, GM_RESULT~CONCAT_WEL+GM_LATITUD +GM_LONGITU, mean)
DataT <-aggregate(DataT, GM_RESULT~CONCAT_WEL+GM_LATITUD +GM_LONGITU+DEPTH_ZONE, mean)
write.csv(DataT, "TurlockInterpolationVAllZones.csv")

#Trend
#Turlock 
Tur <-read.csv("Turlock_2000_Wells.csv")
Tur <-subset(Tur, GM_WELL_CA =="DOMESTIC")
Tur$date <-as.Date(Tur$GM_SAMP_CO,format ='%m/%d/%Y' )
Tur <-Tur %>% 
  group_by(MODIFIED_G) %>% 
  mutate(frequency = n()) %>% 
  data.frame()
#Dom$depth <-Dom$bottom_of_
Tur<-subset(Tur, frequency>5)
Tur <-subset()
list(unique(Tur$MODIFIED_G))
#56 total wells

Dom1 <-subset(Dom, well_ID =="GADAIRY00010-ROB-MW8S")
Dom1 <-arrange(Dom1, date)
avector <- as.vector(Dom1['results'])
MannKendall(avector$results)
sens.slope(avector$results)
#Modesto
Mod <-read.csv("Modesto_2000_Wells.csv")
Mod <-subset(Mod, GM_WELL_CA =="DOMESTIC")
Mod$date <-as.Date(Mod$GM_SAMP_CO,format ='%m/%d/%Y' )
Mod <-Mod %>% 
  group_by(MODIFIED_G) %>% 
  mutate(frequency = n()) %>% 
  data.frame()
#Dom$depth <-Dom$bottom_of_
Mod<-subset(Mod, frequency>5)

list(unique(Mod$MODIFIED_G))
#52 domestic wells
Dom1 <-subset(Dom, well_ID =="GADAIRY00010-ROB-MW8S")
Dom1 <-arrange(Dom1, date)
avector <- as.vector(Dom1['results'])
MannKendall(avector$results)
sens.slope(avector$results)
#modesto Municipal
Mod <-read.csv("Modesto_2000_Wells.csv")
Mod <-subset(Mod, GM_WELL_CA =="MUNICIPAL")
Mod$date <-as.Date(Mod$GM_SAMP_CO,format ='%m/%d/%Y' )
Mod <-Mod %>% 
  group_by(MODIFIED_G) %>% 
  mutate(frequency = n()) %>% 
  data.frame()
#Dom$depth <-Dom$bottom_of_
Mod<-subset(Mod, frequency>5)
Mod <-subset(Mod, DEPTH_ZONE == "Upper")

list(unique(Mod$MODIFIED_G))
#151 Municipal wells
Dom1 <-subset(Dom, well_ID =="GADAIRY00010-ROB-MW8S")
Dom1 <-arrange(Dom1, date)
avector <- as.vector(Dom1['results'])
MannKendall(avector$results)
sens.slope(avector$results)

#modesto Monitoring 

#allAreas
#domestic 
VCW <-read.csv("VCW_Post 2000.csv")
VCW$date <-as.Date(VCW$GM_SAMP_CO,format ='%m/%d/%Y' )
VCW <-subset(VCW, GM_WELL_CA =="DOMESTIC")
VCW <-VCW %>% 
  group_by(MODIFIED_G) %>% 
  mutate(frequency = n()) %>% 
  data.frame()
#Dom$depth <-Dom$bottom_of_
VCW<-subset(VCW, frequency>10)
VCW <-subset(VCW, DEPTH_ZONE == "Upper")
list(unique(VCW$MODIFIED_G))

#56 total domestic wells

Dom <-subset(VCW, MODIFIED_G =="AGW080014842-HOME")
Dom <-aggregate(Dom, GM_RESULT~date, mean)
Dom <-arrange(Dom, date)
#Data <-aggregate(Data, GM_RESULT~CONCAT_WEL+GM_LATITUD +GM_LONGITU, mean)
avector <- as.vector(Dom['GM_RESULT'])
#MannKendall(avector$results)
sens.slope(avector$GM_RESULT)



#monitoring
VCW <-read.csv("VCW_Post 2000.csv")
VCW$date <-as.Date(VCW$GM_SAMP_CO,format ='%m/%d/%Y' )
VCW <-subset(VCW, GM_WELL_CA =="MONITORING")
VCW <-VCW %>% 
  group_by(MODIFIED_G) %>% 
  mutate(frequency = n()) %>% 
  data.frame()
#Dom$depth <-Dom$bottom_of_
VCW<-subset(VCW, frequency>10)
VCW <-subset(VCW, DEPTH_ZONE == "Upper")
list(unique(VCW$MODIFIED_G))
#216 Monitorng

Mon <-subset(VCW, MODIFIED_G =="GADAIRY00010-ROB-MW6D")
Mon <-aggregate(Mon, GM_RESULT~date, mean)
Mon <-arrange(Mon, date)
#Data <-aggregate(Data, GM_RESULT~CONCAT_WEL+GM_LATITUD +GM_LONGITU, mean)
avector <- as.vector(Mon['GM_RESULT'])
#MannKendall(avector$results)
sens.slope(avector$GM_RESULT)




#municipal
VCW <-read.csv("VCW_Post 2000.csv")
VCW$date <-as.Date(VCW$GM_SAMP_CO,format ='%m/%d/%Y' )
VCW <-subset(VCW, GM_WELL_CA =="MUNICIPAL")
VCW <-VCW %>% 
  group_by(MODIFIED_G) %>% 
  mutate(frequency = n()) %>% 
  data.frame()
#Dom$depth <-Dom$bottom_of_
VCW<-subset(VCW, frequency>5)
VCW <-subset(VCW, DEPTH_ZONE == "Upper")
list(unique(VCW$MODIFIED_G))
#183 Municiapl

Mun <-subset(VCW, MODIFIED_G =="CA5000578_001_001")
Mun <-aggregate(Mun, GM_RESULT~date, mean)
Mun <-arrange(Mun, date)
#Data <-aggregate(Data, GM_RESULT~CONCAT_WEL+GM_LATITUD +GM_LONGITU, mean)
avector <- as.vector(Mun['GM_RESULT'])
#MannKendall(avector$results)
sens.slope(avector$GM_RESULT)
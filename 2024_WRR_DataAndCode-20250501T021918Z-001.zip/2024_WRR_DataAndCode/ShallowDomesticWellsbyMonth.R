install.packages("tidyverse", dependencies = TRUE)
library(tidyverse)
library(dplyr)
setwd("P:/ENVS/ENVS116/Datasets/CRLA/2000_2023GAMAData")
Data <-read.csv("VCW_Post 2000.csv")
Data$date <-as.Date(Data$GM_SAMP_CO,format ='%m/%d/%Y' )
Data <-subset(Data, date >="2009-09-30")
Data <-subset(Data, DEPTH_ZONE == "Upper")

Df <-Data %>%
  dplyr::mutate(year = lubridate::year(date), 
                month = lubridate::month(date), 
                day = lubridate::day(date))
Df[Df$month == "1", "month"] = "Jan"
Df[Df$month == "2", "month"] = "Feb"
Df[Df$month == "3", "month"] = "Mar"
Df[Df$month == "4", "month"] = "Apr"
Df[Df$month == "5", "month"] = "May"
Df[Df$month == "6", "month"] = "Jun"
Df[Df$month == "7", "month"] = "Jul"
Df[Df$month == "8", "month"] = "Aug"
Df[Df$month == "9", "month"] = "Sep"
Df[Df$month == "10", "month"] = "Oct"
Df[Df$month == "11", "month"] = "Nov"
Df[Df$month == "12", "month"] = "Dec"

Summary <-summarise(group_by(Df, month), meanMcL =mean(GM_RESULT1), std = sd(GM_RESULT1), 
                    count = n())
Summary$month = factor(Summary$month, levels = month.abb)
#add standrard error as well as above 7.5 same graphic 
#Summary$month <- factor(Summary$month, levels=month.name)

ggplot(Summary, aes(x = month, y = meanMcL)) +theme_classic()+
  geom_bar(stat= "identity", width = 0.6, fill= "#C4A484")+
  ylim(0,15)+
  theme_bw(base_size = 14) +
  theme(axis.text.x=element_text(angle=90,hjust=1, size = 20)) +
  labs(
       x="Month", y = "Nitrate (mg/L)")+
  geom_hline(yintercept=10, linetype= "dotted", color ="red",  size =2, show.legend = TRUE )+
  annotate("text", x=0.1, y=10.5, label=".         MCL", size = 8, color = "black")+
  theme(
    axis.title.x = element_text(size = 20), # Adjust the size as needed
    axis.title.y = element_text(size = 20), 
    plot.title = element_text(size = 20, color = "black"), 
    axis.text = element_text(size = 20,color = "black"))


Data <-data.frame(time = time(Temp), 
                  year = as.integer(time(Temp)), 
                  month = cycle(Temp),
                  date = as.Date(sprintf("%d-%d-01", as.integer(time(Temp)), cycle(Temp))),
                  Temp= tsclean(Temp))
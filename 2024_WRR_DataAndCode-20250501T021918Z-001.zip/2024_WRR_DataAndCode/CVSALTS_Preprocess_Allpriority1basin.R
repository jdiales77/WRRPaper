install.packages("datefixR")
library(datefixR)
#One to many joins for CVSALTS data 
#kings 
KWAWell <-read.csv("KingsWellInfo.csv")
KWANitrate <-read.csv("KingsNitrData.csv")
intersect(names(KWAWell),
          names(KWANitrate))

KWA_All <- merge(KWANitrate,
                   KWAWell,
                   by.x = "MODIFIED_GM_WELL_ID",
                   by.y = "MODIFIED_GM_WELL_ID",
                   all.x = T)
#Write complete CSV
write.csv(KWA_All, "KWA_ALlWellData.csv")
UpperKWA <- subset(KWA_All, DEPTH_ZONE == "Upper") #get only wells in upper basin 
#format date 
UpperKWA$date <-as.Date(UpperKWA$GM_SAMP_COLLECTION_DATE,format ='%m/%d/%Y' )
UpperKWAPost2010 <-subset(UpperKWA, date >="2009-09-30")


write.csv(UpperKWAPost2010, "KWA_ALlWellDataPost2010.csv")

#summary table 

summary <- summarise(group_by(UpperKWAPost2010, GM_DATA_SOURCE),count = n(), meanN =mean(GM_RESULT))

#calculate the mean for each year for each well. 
  #format date to just year. The goal here is to first average the values per well per year 
UpperKWAPost2010$GM_SAMP_COLLECTION_DATE<-format(as.Date(UpperKWAPost2010$GM_SAMP_COLLECTION_DATE, format="%d/%m/%Y"),"%Y")
#takes avergae of each well by year 
UpperKWAPost2010Means <- aggregate(GM_RESULT ~ MODIFIED_GM_WELL_ID + GM_SAMP_COLLECTION_DATE, 
                                   data = UpperKWAPost2010, FUN = mean, na.rm = TRUE)
#AVERAGE now each well 
UpperKWAKrigingPost2010 <-aggregate(GM_RESULT ~ MODIFIED_GM_WELL_ID,
                                     data = UpperKWAPost2010Means, FUN = mean, na.rm = TRUE)
#reattch the Long and latitude

KWA_All_IntFinal <- merge(UpperKWAKrigingPost2010,
                 KWAWell,
                 by.x = "MODIFIED_GM_WELL_ID",
                 by.y = "MODIFIED_GM_WELL_ID",
                 all.x = T)
#drop extra columns 
KWA_All_IntFinal <- subset(KWA_All_IntFinal, select = -c(GM_WELL_DEPTH_FT, GM_TOP_DEPTH_OF_SCREEN_FT,
                                                         GM_SCREEN_LENGTH_FT))

write.csv(KWA_All_IntFinal, "KWA_ALl_IntFinal.csv")
#compare data for pre and post CVSALTS
#What areas are consistently over MCL 

#Kaweah
KawWell <-read.csv("Kaweah_Wellinfo.csv")
KawNitrate <-read.csv("Kaweah_Nitrateinfo.csv")
intersect(names(KawWell),
          names(KawNitrate))
#names 
Kaweah_All <- merge(KawNitrate,
                 KawWell,
                 by.x = "MODIFIED_GM_WELL_ID",
                 by.y = "MODIFIED_GM_WELL_ID",
                 all.x = T)
#Write complete CSV
write.csv(Kaweah_All, "Kaweah_ALlWellData.csv")


UpperKaweah <- subset(Kaweah_All, DEPTH_ZONE == "Upper") #get only wells in upper basin 
#format date. I believe this is the issue
UpperKaweah$date <-as.Date(UpperKaweah$DATE_NUMERICAL,origin = "1899-12-30" )

            
#UpperKaweah$date <-as.Date(UpperKaweah$GM_SAMP_COLLECTION_DATE, format ='%m/%d/%Y' )
UpperKaweahPost2000 <-subset(UpperKaweah, date >= "1999-09-30")
UpperKaweahPost2010 <-subset(UpperKaweah, date >="2009-09-30")

#write post 2000 for trends and post 2010 for interpolation 
write.csv(UpperKaweahPost2000, "Kaweah_ALlWellDataPost2000.csv")
write.csv(UpperKaweahPost2010, "Kaweah_ALlWellDataPost2010.csv")

#next steps for interpolation only 
#takes avergae of each well by year 
UpperKaweahPost2010  <- aggregate(GM_RESULT ~ MODIFIED_GM_WELL_ID + GM_SAMP_COLLECTION_DATE, 
                                   data = UpperKaweahPost2010 , FUN = mean, na.rm = TRUE)
#AVERAGE now each well 
UpperKaweahPost2010<-aggregate(GM_RESULT ~ MODIFIED_GM_WELL_ID,
                                    data = UpperKaweahPost2010, FUN = mean, na.rm = TRUE)
#reattch the Long and latitude

Kaweah_All_IntFinal <- merge(UpperKaweahPost2010,
                          KawWell,
                          by.x = "MODIFIED_GM_WELL_ID",
                          by.y = "MODIFIED_GM_WELL_ID",
                          all.x = T)
write.csv(Kaweah_All_IntFinal, "Kaweah_ALl_IntFinal_JD.csv")


#chowchilla 

ChowWell <-read.csv("ChowchillaWellCVSALTS.csv")
ChowNitrate <-read.csv("ChowchillaNitrateCVSALTS.csv")
intersect(names(ChowWell),
          names(ChowNitrate))
#names 
Chow_All <- merge(ChowNitrate,
                    ChowWell,
                    by.x = "MODIFIED_GM_WELL_ID",
                    by.y = "MODIFIED_GM_WELL_ID",
                    all.x = T)

#Sam start here for Tule
write.csv(Chow_All, "Chow_ALlWellData.csv")
UpperChow <- subset(Chow_All, DEPTH_ZONE == "Upper") #get only wells in upper basin 
#format date. I believe this is the issue
UpperChow$date <-as.Date(UpperChow$DATE_NUMERICAL,origin = "1899-12-30")


UpperChowPost2000 <-subset(UpperChow, date >= "1999-09-30")
UpperChowPost2010 <-subset(UpperChow, date >="2009-09-30")

#write post 2000 for trends and post 2010 for interpolation 
write.csv(UpperChowPost2000, "Chow_ALlWellDataPost2000.csv")
write.csv(UpperChowPost2010, "Chow_ALlWellDataPost2010.csv")


#next steps for interpolation only 
#takes avergae of each well by year 
UpperChowPost2010  <- aggregate(GM_RESULT ~ MODIFIED_GM_WELL_ID + GM_SAMP_COLLECTION_DATE, 
                                  data = UpperChowPost2010 , FUN = mean, na.rm = TRUE)
#AVERAGE now each well 
UpperChowPost2010<-aggregate(GM_RESULT ~ MODIFIED_GM_WELL_ID,
                               data = UpperChowPost2010, FUN = mean, na.rm = TRUE)
#reattch the Long and latitude

Chow_All_IntFinal <- merge(UpperChowPost2010,
                             ChowWell,
                             by.x = "MODIFIED_GM_WELL_ID",
                             by.y = "MODIFIED_GM_WELL_ID",
                             all.x = T)
write.csv(Chow_All_IntFinal, "Chow_ALl_IntFinal.csv")



### GAMA - 2021 data download
# Author: Lilah Foster email: lafoster@scu.edu
#Editor Jake Dialesandro email: jdialesandro@scu.edu
#working on updating for all 21 counties of Central Valley
# Date last modified: 7/07/2023

setwd("~/Google Drive/Shared drives/ModestoWater")

# Clear the working space
rm(list = ls())
rm(modesto_bounds)

library("dplyr")
library("tidyr")
library("stargazer")
library("ggplot2")
library("lubridate")
library("scales")

########## Read in the data
####
##
#

## This data came from here: https://gamagroundwater.waterboards.ca.gov/gama/datadownload
# download the NEW data files not the old ones, they are in a more usable format and have more data points

##### Stanislaus County #####2023
setwd("~/Google Drive/Shared drives/ModestoWater")
#DDW
DDW <- read.delim("02_Data/01_Well_Data/GAMA_2023/Stanislaus/gama_ddw_stanislaus_v2.txt", header = TRUE, sep = "\t", dec = ".")
## just testing the difference between historical and v2
  #DDW_hist <- read.delim("/Users/Lilah/Desktop/SCU/Research_Iris/Data/01_Well_Data/GAMA_2021/gama_ddw_stanislaus.txt", header = TRUE, sep = "\t", dec = ".")
  #DDW_N<- DDW %>% filter(GM_CHEMICAL_VVL == "NO3N")
  #DDW_HN<- DDW_hist %>% filter(CHEMICAL == "NO3N")
#DPR (HAS NO NITRATE DATA)**********
DPR <- read.delim("02_Data/01_Well_Data/GAMA_2023/Stanislaus/gama_dpr_stanislaus_v2.txt", header = TRUE, sep = "\t", dec = ".")
#DWR (HAS NO DATA PAST 1979)*********
DWR <- read.delim("02_Data/01_Well_Data/GAMA_2023/Stanislaus/gama_dwr_stanislaus_v2.txt", header = TRUE, sep = "\t", dec = ".")
#GAMA SP Study
SP_Study <- read.delim("02_Data/01_Well_Data/GAMA_2023/Stanislaus/gama_gama_sp-study_stanislaus_v2.txt", header = TRUE, sep = "\t", dec = ".")
#GAMA USGS
USGS <- read.delim("02_Data/01_Well_Data/GAMA_2023/Stanislaus/gama_gama_usgs_stanislaus_v2.txt", header = TRUE, sep = "\t", dec = ".")
#USGS NWIS
NWIS <- read.delim("02_Data/01_Well_Data/GAMA_2023/Stanislaus/gama_usgs_nwis_stanislaus_v2.txt", header = TRUE, sep = "\t", dec = ".")
#WB Cleanup
WB_Cleanup <- read.delim("02_Data/01_Well_Data/GAMA_2023/Stanislaus/gama_wb_cleanup_stanislaus_v2.txt", header = TRUE, sep = "\t", dec = ".")
#WB ILRP
ILRP <- read.delim("02_Data/01_Well_Data/GAMA_2023/Stanislaus/gama_wb_ilrp_stanislaus_v2.txt", header = TRUE, sep = "\t", dec = ".")

#### Merced County #### 2023
#DDW
DDW_mer <- read.delim("02_Data/01_Well_Data/GAMA_2023/Merced/gama_ddw_merced_v2.txt", header = TRUE, sep = "\t", dec = ".")
#DPR (HAS NO NITRATE DATA)**********
DPR_mer <- read.delim("02_Data/01_Well_Data/GAMA_2023/Merced/gama_dpr_merced_v2.txt", header = TRUE, sep = "\t", dec = ".")
#DWR (HAS NO DATA PAST 1979)*********
DWR_mer <- read.delim("02_Data/01_Well_Data/GAMA_2023/Merced/gama_dwr_merced_v2.txt", header = TRUE, sep = "\t", dec = ".")
#GAMA SP Study
### THIS DOES NOT EXIST FOR MERCED
#SP_Study_mer <- read.delim("/Users/Lilah/Desktop/SCU/Research_Iris/Data/01_Well_Data/GAMA_2021/gama_gama_sp-study_merced_v2.txt", header = TRUE, sep = "\t", dec = ".")
#GAMA USGS
USGS_mer <- read.delim("02_Data/01_Well_Data/GAMA_2023/Merced/gama_gama_usgs_merced_v2.txt", header = TRUE, sep = "\t", dec = ".")
#USGS NWIS
NWIS_mer <- read.delim("02_Data/01_Well_Data/GAMA_2023/Merced/gama_usgs_nwis_merced_v2.txt", header = TRUE, sep = "\t", dec = ".")
#WB Cleanup
WB_Cleanup_mer <- read.delim("02_Data/01_Well_Data/GAMA_2023/Merced/gama_wb_cleanup_merced_v2.txt", header = TRUE, sep = "\t", dec = ".")
#WB ILRP
ILRP_mer <- read.delim("02_Data/01_Well_Data/GAMA_2023/Merced/gama_wb_ilrp_merced_v2.txt", header = TRUE, sep = "\t", dec = ".")

#### San Joaquin County ####
#DDW
DDW_sanj <- read.delim("02_Data/01_Well_Data/GAMA_2023/SanJoaquin/gama_ddw_sanjoaquin_v2.txt", header = TRUE, sep = "\t", dec = ".")
#DPR (HAS NO NITRATE DATA)**********
DPR_sanj <- read.delim("02_Data/01_Well_Data/GAMA_2023/SanJoaquin/gama_dpr_sanjoaquin_v2.txt", header = TRUE, sep = "\t", dec = ".")
#DWR (HAS NO DATA PAST 1979)*********
DWR_sanj <- read.delim("02_Data/01_Well_Data/GAMA_2023/SanJoaquin/gama_dwr_sanjoaquin_v2.txt", header = TRUE, sep = "\t", dec = ".")
#GAMA SP Study
SP_Study_sanj <- read.delim("02_Data/01_Well_Data/GAMA_2023/SanJoaquin/gama_gama_sp-study_sanjoaquin_v2.txt", header = TRUE, sep = "\t", dec = ".")
#GAMA USGS
USGS_sanj <- read.delim("02_Data/01_Well_Data/GAMA_2023/SanJoaquin/gama_gama_usgs_sanjoaquin_v2.txt", header = TRUE, sep = "\t", dec = ".")
#USGS NWIS
NWIS_sanj <- read.delim("02_Data/01_Well_Data/GAMA_2023/SanJoaquin/gama_usgs_nwis_sanjoaquin_v2.txt", header = TRUE, sep = "\t", dec = ".")
#WB Cleanup
WB_Cleanup_sanj <- read.delim("02_Data/01_Well_Data/GAMA_2023/SanJoaquin/gama_wb_cleanup_sanjoaquin_v2.txt", header = TRUE, sep = "\t", dec = ".")
#WB ILRP
ILRP_sanj <- read.delim("02_Data/01_Well_Data/GAMA_2023/SanJoaquin/gama_wb_ilrp_sanjoaquin_v2.txt", header = TRUE, sep = "\t", dec = ".")

#### Tuolumne County ####
#DDW
DDW_tuo <- read.delim("02_Data/01_Well_Data/GAMA_2023/Toulumne/gama_ddw_tuolumne_v2.txt", header = TRUE, sep = "\t", dec = ".")
#DPR (HAS NO NITRATE DATA)**********
DPR_tuo <- read.delim("02_Data/01_Well_Data/GAMA_2023/Toulumne/gama_dpr_tuolumne_v2.txt", header = TRUE, sep = "\t", dec = ".")
#DWR (HAS NO DATA PAST 1979)*********
DWR_tuo <- read.delim("02_Data/01_Well_Data/GAMA_2023/Toulumne/gama_dwr_tuolumne_v2.txt", header = TRUE, sep = "\t", dec = ".")
#GAMA SP Study
### SP_Study_tuo <- read.delim("/Users/Lilah/Desktop/SCU/Research_Iris/Data/01_Well_Data/GAMA_2021/gama_gama_sp-study_tuolumne_v2.txt", header = TRUE, sep = "\t", dec = ".")
#GAMA USGS (HAS NO DATA FOR TUOLUMNE)
USGS_tuo <- read.delim("02_Data/01_Well_Data/GAMA_2023/Toulumne/gama_gama_usgs_tuolumne_v2.txt", header = TRUE, sep = "\t", dec = ".")
#USGS NWIS
NWIS_tuo <- read.delim("02_Data/01_Well_Data/GAMA_2023/Toulumne/gama_usgs_nwis_tuolumne_v2.txt", header = TRUE, sep = "\t", dec = ".")
#WB Cleanup
WB_Cleanup_tuo <- read.delim("02_Data/01_Well_Data/GAMA_2023/Toulumne/gama_wb_cleanup_tuolumne_v2.txt", header = TRUE, sep = "\t", dec = ".")
#WB ILRP
ILRP_tuo <- read.delim("02_Data/01_Well_Data/GAMA_2023/Toulumne/gama_wb_ilrp_tuolumne_v2.txt", header = TRUE, sep = "\t", dec = ".")

#Sacramento  County
#yolo County
#



########## Cleaning the data ####
####
##
#

### Filter to Just Nitrate
#stanislaus
DDW_N<- DDW %>% filter(GM_CHEMICAL_VVL == "NO3N")
DPR_N<- DPR %>% filter(GM_CHEMICAL_VVL == "NO3N")
DWR_N<- DWR %>% filter(GM_CHEMICAL_VVL == "NO3N")
SP_Study_N<- SP_Study %>% filter(GM_CHEMICAL_VVL == "NO3N")
USGS_N<- USGS %>% filter(GM_CHEMICAL_VVL == "NO3N")
NWIS_N<- NWIS %>% filter(GM_CHEMICAL_VVL == "NO3N")
WB_Cleanup_N<- WB_Cleanup %>% filter(GM_CHEMICAL_VVL == "NO3N")
ILRP_N<- ILRP %>% filter(GM_CHEMICAL_VVL == "NO3N")
#merced
DDW_N_mer<- DDW_mer %>% filter(GM_CHEMICAL_VVL == "NO3N")
DPR_N_mer<- DPR_mer %>% filter(GM_CHEMICAL_VVL == "NO3N")
DWR_N_mer<- DWR_mer %>% filter(GM_CHEMICAL_VVL == "NO3N")
USGS_N_mer<- USGS_mer %>% filter(GM_CHEMICAL_VVL == "NO3N")
NWIS_N_mer<- NWIS_mer %>% filter(GM_CHEMICAL_VVL == "NO3N")
WB_Cleanup_N_mer<- WB_Cleanup_mer %>% filter(GM_CHEMICAL_VVL == "NO3N")
ILRP_N_mer<- ILRP_mer %>% filter(GM_CHEMICAL_VVL == "NO3N")
#sanJoaquin
DDW_N_sanj<- DDW_sanj %>% filter(GM_CHEMICAL_VVL == "NO3N")
DPR_N_sanj<- DPR_sanj %>% filter(GM_CHEMICAL_VVL == "NO3N")
DWR_N_sanj<- DWR_sanj %>% filter(GM_CHEMICAL_VVL == "NO3N")
SP_Study_N_sanj<- SP_Study_sanj %>% filter(GM_CHEMICAL_VVL == "NO3N")
USGS_N_sanj<- USGS_sanj %>% filter(GM_CHEMICAL_VVL == "NO3N")
NWIS_N_sanj<- NWIS_sanj %>% filter(GM_CHEMICAL_VVL == "NO3N")
WB_Cleanup_N_sanj<- WB_Cleanup_sanj %>% filter(GM_CHEMICAL_VVL == "NO3N")
ILRP_N_sanj<- ILRP_sanj %>% filter(GM_CHEMICAL_VVL == "NO3N")
#tuolumne
DDW_N_tuo<- DDW_tuo %>% filter(GM_CHEMICAL_VVL == "NO3N")
DPR_N_tuo<- DPR_tuo %>% filter(GM_CHEMICAL_VVL == "NO3N")
DWR_N_tuo<- DWR_tuo %>% filter(GM_CHEMICAL_VVL == "NO3N")
USGS_N_tuo<- USGS_tuo %>% filter(GM_CHEMICAL_VVL == "NO3N")
NWIS_N_tuo<- NWIS_tuo %>% filter(GM_CHEMICAL_VVL == "NO3N")
WB_Cleanup_N_tuo<- WB_Cleanup_tuo %>% filter(GM_CHEMICAL_VVL == "NO3N")
ILRP_N_tuo<- ILRP_tuo %>% filter(GM_CHEMICAL_VVL == "NO3N")

## Format dates to be recognized as dates
#stanislaus
DDW_N$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", DDW_N$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
DPR_N$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", DPR_N$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
DWR_N$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", DWR_N$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
SP_Study_N$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", SP_Study_N$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
USGS_N$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", USGS_N$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
NWIS_N$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", NWIS_N$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
WB_Cleanup_N$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", WB_Cleanup_N$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
ILRP_N$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", ILRP_N$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
#merced
DDW_N_mer$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", DDW_N_mer$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
DPR_N_mer$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", DPR_N_mer$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
DWR_N_mer$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", DWR_N_mer$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
USGS_N_mer$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", USGS_N_mer$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
NWIS_N_mer$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", NWIS_N_mer$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
WB_Cleanup_N_mer$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", WB_Cleanup_N_mer$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
ILRP_N_mer$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", ILRP_N_mer$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
#sanjoaquin
DDW_N_sanj$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", DDW_N_sanj$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
DPR_N_sanj$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", DPR_N_sanj$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
DWR_N_sanj$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", DWR_N_sanj$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
SP_Study_N_sanj$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", SP_Study_N_sanj$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
USGS_N_sanj$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", USGS_N_sanj$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
NWIS_N_sanj$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", NWIS_N_sanj$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
WB_Cleanup_N_sanj$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", WB_Cleanup_N_sanj$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
ILRP_N_sanj$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", ILRP_N_sanj$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
#tuolumne
DDW_N_tuo$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", DDW_N_tuo$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
DPR_N_tuo$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", DPR_N_tuo$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
DWR_N_tuo$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", DWR_N_tuo$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
USGS_N_tuo$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", USGS_N_tuo$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
NWIS_N_tuo$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", NWIS_N_tuo$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
WB_Cleanup_N_tuo$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", WB_Cleanup_N_tuo$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
ILRP_N_tuo$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", ILRP_N_tuo$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")

##Filtering by date from 1999-2023
#stanislaus
DDW_N<- DDW_N %>% filter(GM_SAMP_COLLECTION_DATE>"1999-01-01"& GM_SAMP_COLLECTION_DATE<"2023-05-01")
DPR_N<-DPR_N%>% filter(GM_SAMP_COLLECTION_DATE>"1999-01-01"& GM_SAMP_COLLECTION_DATE<"2023-05-01")
DWR_N<-DWR_N%>% filter(GM_SAMP_COLLECTION_DATE>"1999-01-01"& GM_SAMP_COLLECTION_DATE<"2023-05-01")
SP_Study_N<-SP_Study_N%>% filter(GM_SAMP_COLLECTION_DATE>"1999-01-01"& GM_SAMP_COLLECTION_DATE<"2023-05-01")
USGS_N<-USGS_N%>% filter(GM_SAMP_COLLECTION_DATE>"1999-01-01"& GM_SAMP_COLLECTION_DATE<"2023-05-01")
NWIS_N<-NWIS_N%>% filter(GM_SAMP_COLLECTION_DATE>"1999-01-01"& GM_SAMP_COLLECTION_DATE<"2023-05-01")
WB_Cleanup_N<-WB_Cleanup_N%>% filter(GM_SAMP_COLLECTION_DATE>"1999-01-01"& GM_SAMP_COLLECTION_DATE<"2023-05-01")
ILRP_N<-ILRP_N%>% filter(GM_SAMP_COLLECTION_DATE>"1999-01-01"& GM_SAMP_COLLECTION_DATE<"2023-05-01")
#merced
DDW_N_mer<- DDW_N_mer %>% filter(GM_SAMP_COLLECTION_DATE>"1999-01-01"& GM_SAMP_COLLECTION_DATE<"2023-05-01")
DPR_N_mer<-DPR_N_mer%>% filter(GM_SAMP_COLLECTION_DATE>"1999-01-01"& GM_SAMP_COLLECTION_DATE<"2023-05-01")
DWR_N_mer<-DWR_N_mer%>% filter(GM_SAMP_COLLECTION_DATE>"1999-01-01"& GM_SAMP_COLLECTION_DATE<"2023-05-01")
USGS_N_mer<-USGS_N_mer%>% filter(GM_SAMP_COLLECTION_DATE>"1999-01-01"& GM_SAMP_COLLECTION_DATE<"2023-05-01")
NWIS_N_mer<-NWIS_N_mer%>% filter(GM_SAMP_COLLECTION_DATE>"1999-01-01"& GM_SAMP_COLLECTION_DATE<"2023-05-01")
WB_Cleanup_N_mer<-WB_Cleanup_N_mer%>% filter(GM_SAMP_COLLECTION_DATE>"1999-01-01"& GM_SAMP_COLLECTION_DATE<"2023-05-01")
ILRP_N_mer<-ILRP_N_mer%>% filter(GM_SAMP_COLLECTION_DATE>"1999-01-01"& GM_SAMP_COLLECTION_DATE<"2023-05-01")
#sanjoaquin
DDW_N_sanj<- DDW_N_sanj %>% filter(GM_SAMP_COLLECTION_DATE>"1999-01-01"& GM_SAMP_COLLECTION_DATE<"2023-05-01")
DPR_N_sanj<-DPR_N_sanj%>% filter(GM_SAMP_COLLECTION_DATE>"1999-01-01"& GM_SAMP_COLLECTION_DATE<"2023-05-01")
DWR_N_sanj<-DWR_N_sanj%>% filter(GM_SAMP_COLLECTION_DATE>"1999-01-01"& GM_SAMP_COLLECTION_DATE<"2023-05-01")
SP_Study_N_sanj<-SP_Study_N_sanj%>% filter(GM_SAMP_COLLECTION_DATE>"1999-01-01"& GM_SAMP_COLLECTION_DATE<"2023-05-01")
USGS_N_sanj<-USGS_N_sanj%>% filter(GM_SAMP_COLLECTION_DATE>"1999-01-01"& GM_SAMP_COLLECTION_DATE<"2023-05-01")
NWIS_N_sanj<-NWIS_N_sanj%>% filter(GM_SAMP_COLLECTION_DATE>"1999-01-01"& GM_SAMP_COLLECTION_DATE<"2023-05-01")
WB_Cleanup_N_sanj<-WB_Cleanup_N_sanj%>% filter(GM_SAMP_COLLECTION_DATE>"1999-01-01"& GM_SAMP_COLLECTION_DATE<"2023-05-01")
ILRP_N_sanj<-ILRP_N_sanj%>% filter(GM_SAMP_COLLECTION_DATE>"1999-01-01"& GM_SAMP_COLLECTION_DATE<"2023-05-01")
#toulumne
DDW_N_tuo<- DDW_N_tuo %>% filter(GM_SAMP_COLLECTION_DATE>"1999-01-01"& GM_SAMP_COLLECTION_DATE<"2023-05-01")
DPR_N_tuo<-DPR_N_tuo%>% filter(GM_SAMP_COLLECTION_DATE>"1999-01-01"& GM_SAMP_COLLECTION_DATE<"2023-05-01")
DWR_N_tuo<-DWR_N_tuo%>% filter(GM_SAMP_COLLECTION_DATE>"1999-01-01"& GM_SAMP_COLLECTION_DATE<"2023-05-01")
USGS_N_tuo<-USGS_N_tuo%>% filter(GM_SAMP_COLLECTION_DATE>"1999-01-01"& GM_SAMP_COLLECTION_DATE<"2023-05-01")
NWIS_N_tuo<-NWIS_N_tuo%>% filter(GM_SAMP_COLLECTION_DATE>"1999-01-01"& GM_SAMP_COLLECTION_DATE<"2023-05-01")
WB_Cleanup_N_tuo<-WB_Cleanup_N_tuo%>% filter(GM_SAMP_COLLECTION_DATE>"1999-01-01"& GM_SAMP_COLLECTION_DATE<"2023-05-01")
ILRP_N_tuo<-ILRP_N_tuo%>% filter(GM_SAMP_COLLECTION_DATE>"1999-01-01"& GM_SAMP_COLLECTION_DATE<"2023-05-01")


## Merge the datasets
GAMA_stan<- rbind(DDW_N, DPR_N, DWR_N, SP_Study_N, USGS_N, NWIS_N, WB_Cleanup_N, ILRP_N)
GAMA_mer<- rbind(DDW_N_mer, DPR_N_mer, DWR_N_mer, USGS_N_mer, NWIS_N_mer, WB_Cleanup_N_mer, ILRP_N_mer)
GAMA_sanj<- rbind(DDW_N_sanj, DPR_N_sanj, DWR_N_sanj, SP_Study_N_sanj, USGS_N_sanj, NWIS_N_sanj, WB_Cleanup_N_sanj, ILRP_N_sanj)
GAMA_tuo<- rbind(DDW_N_tuo, DPR_N_tuo, DWR_N_tuo, USGS_N_tuo, NWIS_N_tuo, WB_Cleanup_N_tuo, ILRP_N_tuo)


## Add a county column
GAMA_stan<- GAMA_stan%>%
  mutate(county = "stanislaus")
GAMA_mer<- GAMA_mer%>%
  mutate(county = "merced")
GAMA_sanj<- GAMA_sanj%>%
  mutate(county = "san joaquin")
GAMA_tuo<- GAMA_tuo%>%
  mutate(county = "tuolumne")

## Merge to one big dataset
GAMA <- rbind(GAMA_stan, GAMA_mer, GAMA_sanj, GAMA_tuo)

## Rename the headers 
GAMA <- GAMA%>% rename("results"= "GM_RESULT")%>%
  rename("long" = "GM_LONGITUDE")%>%
  rename("lat" = "GM_LATITUDE")%>%
  rename("MCL"= "GM_REPORTING_LIMIT")%>%
  rename("well.ID"="GM_WELL_ID")%>%
  rename("chem.ID"= "GM_CHEMICAL_VVL")%>%
  rename("chem"= "GM_CHEMICAL_NAME")%>%
  rename("unit"="GM_CHEMICAL_UNITS")%>%
  rename("well.depth.ft"= "GM_WELL_DEPTH_FT")%>%
  rename("data.source"= "GM_DATASET_NAME")%>%
  rename("well.type"= "GM_WELL_CATEGORY")%>%
  rename("top.of.screen.ft"= "GM_TOP_DEPTH_OF_SCREEN_FT")%>%
  rename("bottom.of.screen.ft"= "GM_BOTTOM_DEPTH_OF_SCREEN_FT")%>%
  rename("date"= "GM_SAMP_COLLECTION_DATE")

## Remove unnecessary columns
GAMA<- subset(GAMA, select= c(results, long, lat, MCL, well.ID, chem.ID, chem, unit, well.depth.ft,
                              data.source, well.type, top.of.screen.ft, bottom.of.screen.ft, date, county))
#is date unneccesary, becasue we use in next script?

## Save as a CSV for later use
write.csv(GAMA,'GAMA_2000_2023_Well_Data_01_JD.csv')

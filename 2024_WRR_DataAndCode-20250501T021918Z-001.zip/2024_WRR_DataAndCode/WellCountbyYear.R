AllWells <-read_csv("VWCPost200_AllWellTests_AllData.csv")

AllWells$GM_SAMP_CO <-as.Date(AllWells$GM_SAMP_CO,format ='%m/%d/%Y' )
length(unique(AllWells$MODIFIED_G)) 
AW2000 <-subset(AllWells, GM_SAMP_CO >="1999-09-30" & GM_SAMP_CO <= "2000-09-30")
length(unique(AW2000$MODIFIED_G)) 
AW2000NP <- aggregate(GM_RESULT ~ MODIFIED_G + GM_SAMP_CO, 
                                   data = AW2000, FUN = mean, na.rm = TRUE)
AW2001 <-subset(AllWells, GM_SAMP_CO >="2000-10-01" & GM_SAMP_CO <= "2001-09-30")
length(unique(AW2001$MODIFIED_G)) 
AW2001NP <- aggregate(GM_RESULT ~ MODIFIED_G + GM_SAMP_CO, 
                      data = AW2001, FUN = mean, na.rm = TRUE)

AW2002 <-subset(AllWells, GM_SAMP_CO >="2001-10-01" & GM_SAMP_CO <= "2002-09-30")
length(unique(AW2002$MODIFIED_G)) 
AW2002NP <- aggregate(GM_RESULT ~ MODIFIED_G + GM_SAMP_CO, 
                      data = AW2002, FUN = mean, na.rm = TRUE)

AW2003 <-subset(AllWells, GM_SAMP_CO >="2002-10-01" & GM_SAMP_CO <= "2003-09-30")
length(unique(AW2003$MODIFIED_G)) 
AW2003NP <- aggregate(GM_RESULT ~ MODIFIED_G + GM_SAMP_CO, 
                      data = AW2003, FUN = mean, na.rm = TRUE)

AW2020 <-subset(AllWells, GM_SAMP_CO >="2020-10-01" & GM_SAMP_CO <= "2021-09-30")
length(unique(AW2020$MODIFIED_G)) 
AW2004NP <- aggregate(GM_RESULT ~ MODIFIED_G + GM_SAMP_CO, 
                      data = AW2004, FUN = mean, na.rm = TRUE)

AW2020 <-subset(AllWells, GM_SAMP_CO >="2020-10-01" & GM_SAMP_CO <= "2023-09-30")
length(unique(AW2020$MODIFIED_G)) 
AW2020NP <- aggregate(GM_RESULT ~ MODIFIED_G + GM_SAMP_CO, 
                      data = AW2020, FUN = mean, na.rm = TRUE)
VWC <- subset(AW2020, GM_DATA_SO =="VWC")

df = data.frame(year = 2000:2023,
                Unique_Wells = c(839,203,102,314,428,458,521,533,545,531,557,524,594,603,660,679,655,
                                 680,616,1284,1730,1513,1154,428),
                Unique_Nitrate_Samples = c(3418,458,132,516,1330,1340,1310,2659,1554,1117,1179,
                                           1130,1316,1581,3149,1942,1932,2147,2126,2915,3356,
                                           1848,2230,675))%>%
  pivot_longer(cols = c(Unique_Wells,Unique_Nitrate_Samples), names_to = "Legend", values_to = "count")
df <- df %>%
  mutate(Type = recode(Legend,
                       "Unique_Wells" = "Unique Wells",
                       "Unique_Nitrate_Samples" = "Unique Nitrate Samples"))

df$year <- as.factor(df$year)
every_other_year <- levels(df$year)[seq(1, length(levels(df$year)), by = 2)]
ggplot(df, aes(x = as.factor(year), y = count, fill = Type)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.8)) +
  labs(x = "Year", y = "Count") +
  theme_classic()+theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))+
  scale_x_discrete(breaks = every_other_year) +
  theme(
    axis.title.x = element_text(size = 20), # Adjust the size as needed
    axis.title.y = element_text(size = 20), 
    plot.title = element_text(size = 20, color = "black"), 
    axis.text = element_text(size = 18,color = "black"), # Adjust the size as needed
    legend.position = c(0.3, 0.85), 
    legend.text = element_text(size = 14, color = "black"),  # Adjust size here
    legend.title = element_text(size = 16, color = "black"),# Position the legend in the upper right corner
    legend.background = element_rect(fill = "white", color = "black") # Optional: background color for the legend
  )+
  coord_cartesian(ylim = c(0, 4000))






PBC<-read.csv("WellBarChart.csv")

df |>
  # Reshape data to long format
  pivot_longer(empty:substrate) |> 
  ggplot(aes(x = Year, y = value, fill = name)) +
  # Implement a grouped bar chart
  geom_bar(position = "dodge", stat = "identity")



ggplot(PBS, aes(fill=year, y=value, x=Year)) 
library(tidyr)
df_long <- PBC %>%
  pivot_longer(cols = starts_with("Year"), names_to = "Variable", values_to = "Value")

ggplot(df_long, aes(x = factor(Value), y = Value, fill = Variable)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.8)) +
  labs(x = "Year", y = "Value", title = "Paired Bar Chart of Variable1 and Variable2") +
  theme_minimal()

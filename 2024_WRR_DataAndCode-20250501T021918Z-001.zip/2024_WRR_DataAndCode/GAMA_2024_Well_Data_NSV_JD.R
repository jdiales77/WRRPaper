### GAMA - 2021 data download
# Author: Lilah Foster email: lafoster@scu.edu
#Editor Jake Dialesandro email: jdialesandro@scu.edu
#working on updating for all 21 counties of Central Valley
# Date last modified: 7/07/2023
#May 2024 updated for Southern Central Valley (San Joaquin>Kern)
#This code takes post 2010 data and takes the mean value recorded for each year and then
#the avergae recorded value of the 14 year collection. We also made a layer of maximum values for eahc year
#and avergaed them for the 14 years. This was based on the public comments response from VCW.

setwd("~/Google Drive/Shared drives/CentralValleyWater/02_Data/01_Well_Data/GAMA_2024/")

# Clear the working space
rm(list = ls())
rm(modesto_bounds)

library("dplyr")
library("tidyr")
library("stargazer")
library("ggplot2")
library("lubridate")
library("scales")

########## Read in the data
####
##
#

## This data came from here: https://gamagroundwater.waterboards.ca.gov/gama/datadownload
# download the NEW data files not the old ones, they are in a more usable format and have more data points

##### North Sacramento Valleuy  #####2024
setwd("~/Google Drive/Shared drives/CentralValleyWater/02_Data/01_Well_Data/GAMA_2024/Sacramento_Valley/")
#Yuba
Yuba <- read_delim("Yuba/gama_all_yuba_v2.txt", header = TRUE, sep = "\t", dec = ".") 
#### Yolo County #### 2024
Yolo <-read_delim("Yolo/gama_all_yolo_v2.txt", header = TRUE, sep = "\t", dec = ".")
#### Tehama County ####
Teh <- read.delim("Tehama/gama_all_tehama_v2.txt", header = TRUE, sep = "\t", dec = ".")
#### Sutter County ####
Sut <- read.delim("Sutter/gama_all_sutter_v2.txt", header = TRUE, sep = "\t", dec = ".")
####Solano County####
Sol <-read.delim("Solano/gama_all_solano_v2.txt", header = TRUE, sep = "\t", dec = ".")
####Sacramento  County####
Sac <- read.delim("Sacramento/gama_all_sacramento_v2.txt", header = TRUE, sep = "\t", dec = ".")
####Placer County####
Pla <-read_delim("Placer/gama_all_placer_v2.txt", header = TRUE, sep = "\t", dec = ".")
####Glenn County####
Glenn <-read_delim("Glenn/gama_all_glenn_v2.txt", header = TRUE, sep = "\t", dec = ".")
####Colusa County####
Col <-read_delim("Colusa/gama_all_colusa_v2.txt", header = TRUE, sep = "\t", dec = ".")
####butte County ####
Butte <-read_delim("Butte/gama_all_butte_v2.txt", header = TRUE, sep = "\t", dec = ".")
####Kern County####
#Kern <-read_delim("Kern/gama_all_kern_v2.txt")
####Mariposa County####
#Mari <-read_delim("Mariposa/gama_all_mariposa_v2.txt")
########## Cleaning the data ####
####
##
#

### Filter to Just Nitrate
#Yuba
Yuba <-Yuba %>% filter(GM_CHEMICAL_VVL == "NO3N")
#Yolo
Yolo<- Yolo %>% filter(GM_CHEMICAL_VVL == "NO3N")
#Tehama
Teh<- Teh %>% filter(GM_CHEMICAL_VVL == "NO3N")
#Sutter
Sut<- Sut %>% filter(GM_CHEMICAL_VVL == "NO3N")
#Sacramento
Sac<- Sac %>% filter(GM_CHEMICAL_VVL == "NO3N")
#solano
Sol <-Sol %>% filter(GM_CHEMICAL_VVL == "NO3N")
#Placer
Pla <-Pla %>% filter(GM_CHEMICAL_VVL == "NO3N")
#Glenn 
Glenn<- Glenn %>% filter(GM_CHEMICAL_VVL == "NO3N")
#Colusa
Col<- Col %>% filter(GM_CHEMICAL_VVL == "NO3N")
#Butte
Butte<- Butte %>% filter(GM_CHEMICAL_VVL == "NO3N")
#kern
#Kern<- Kern %>% filter(GM_CHEMICAL_VVL == "NO3N")
#Mari
#Mari <-Mari %>% filter(GM_CHEMICAL_VVL == "NO3N")




## Format dates to be recognized as dates
#Yuba
Yuba$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", Yuba$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
#Yolo
Yolo$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", Yolo$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
#Tehama
Teh$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", Teh$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
#Sutter
Sut$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", Sut$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
#sacramento
Sac$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", Sac$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
#Solano
Sol$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", Sol$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
#Placer
Pla$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", Pla$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
#Glenn
Glenn$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", Glenn$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
#Colusa
Col$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", Col$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
#Butte
Butte$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", Butte$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")
#Mariposa
#Mari$GM_SAMP_COLLECTION_DATE <- as.Date(sub(" .*", "", Mari$GM_SAMP_COLLECTION_DATE), format = "%m/%d/%Y")


##Filtering by date from 2010-2024 Water Years
#Yuba
Yuba <- Yuba %>% filter(GM_SAMP_COLLECTION_DATE>"2009-09-30"& GM_SAMP_COLLECTION_DATE<"2024-05-01")
#Yolo
Yolo<- Yolo %>% filter(GM_SAMP_COLLECTION_DATE>"2009-09-30"& GM_SAMP_COLLECTION_DATE<"2024-05-01")
#Tehama
Teh<- Teh %>% filter(GM_SAMP_COLLECTION_DATE>"2009-09-30"& GM_SAMP_COLLECTION_DATE<"2024-05-01")
#Sutter
Sut<- Sut %>% filter(GM_SAMP_COLLECTION_DATE>"2009-09-30"& GM_SAMP_COLLECTION_DATE<"2024-05-01")
#sacramento=
Sac<- Sac %>% filter(GM_SAMP_COLLECTION_DATE>"2009-09-30"& GM_SAMP_COLLECTION_DATE<"2024-05-01")
#Solano
Sol<-Sol %>% filter(GM_SAMP_COLLECTION_DATE>"2009-09-30"& GM_SAMP_COLLECTION_DATE<"2024-05-01")
#Placer
Pla<- Pla %>% filter(GM_SAMP_COLLECTION_DATE>"2009-09-30"& GM_SAMP_COLLECTION_DATE<"2024-05-01")
#Glenn
Glenn<- Glenn %>% filter(GM_SAMP_COLLECTION_DATE>"2009-09-30"& GM_SAMP_COLLECTION_DATE<"2024-05-01")
#Colusa
Col<- Col %>% filter(GM_SAMP_COLLECTION_DATE>"2009-09-30"& GM_SAMP_COLLECTION_DATE<"2024-05-01")
#Butte
Butte<- Butte %>% filter(GM_SAMP_COLLECTION_DATE>"2009-09-30"& GM_SAMP_COLLECTION_DATE<"2024-05-01")
# Mariposaa
#Mari<- Mari %>% filter(GM_SAMP_COLLECTION_DATE>"2009-09-30"& GM_SAMP_COLLECTION_DATE<"2024-05-01")



## Merge the datasets
## Add a county column
GAMA_yuba<- Yuba%>%
  mutate(county = "yuba")
GAMA_yolo<- Yolo%>%
  mutate(county = "yolo")
GAMA_Teh<- Teh%>%
  mutate(county = "tehama")
GAMA_sut<- Sut%>%
  mutate(county = "sutter")
GAMA_sac <-Sac%>%
  mutate(county = "sacramento")
GAMA_sol <-Sol%>%
  mutate(county="Solano")
GAMA_pla <-Pla%>%
  mutate(county ="placer")
GAMA_glenn <-Glenn%>%
  mutate(county ="glenn")
GAMA_col <-Col%>%
  mutate(county = "colusa")
GAMA_but <-Butte%>%
  mutate(county= "butte")
#GAMA_mari <-Mari%>%
  #mutate(county= "mariposa")


## Merge to one big dataset
GAMA <- rbind(GAMA_yuba, GAMA_yolo, GAMA_Teh, GAMA_sut, GAMA_sac, GAMA_sol,
              GAMA_pla, GAMA_glenn, GAMA_col, GAMA_but)

## Rename the headers 
GAMA <- GAMA%>% rename("results"= "GM_RESULT")%>%
  rename("long" = "GM_LONGITUDE")%>%
  rename("lat" = "GM_LATITUDE")%>%
  rename("MCL"= "GM_REPORTING_LIMIT")%>%
  rename("well.ID"="GM_WELL_ID")%>%
  rename("chem.ID"= "GM_CHEMICAL_VVL")%>%
  rename("chem"= "GM_CHEMICAL_NAME")%>%
  rename("unit"="GM_CHEMICAL_UNITS")%>%
  rename("well.depth.ft"= "GM_WELL_DEPTH_FT")%>%
  rename("data.source"= "GM_DATASET_NAME")%>%
  rename("well.type"= "GM_WELL_CATEGORY")%>%
  rename("top.of.screen.ft"= "GM_TOP_DEPTH_OF_SCREEN_FT")%>%
  rename("bottom.of.screen.ft"= "GM_BOTTOM_DEPTH_OF_SCREEN_FT")%>%
  rename("date"= "GM_SAMP_COLLECTION_DATE")

## Remove unnecessary columns
GAMA<- subset(GAMA, select= c(results, long, lat, MCL, well.ID, chem.ID, chem, unit, well.depth.ft,
                              data.source, well.type, top.of.screen.ft, bottom.of.screen.ft, date, county))
#is date unneccesary, becasue we use in next script?

## Save as a CSV for later use
write.csv(GAMA,'GAMA_2024_Well_Data_01_SCV_AllData.csv')

#calculate the mean for each year for each well. 
#format date to just year. The goal here is to first average the values per well per year 
GAMA$GM_SAMP_COLLECTION_DATE<-format(as.Date(GAMA$date, format="%d/%m/%Y"),"%Y")
#takes avergae of each well by year 
GAMAPost2010Means <- aggregate(results ~ well.ID + GM_SAMP_COLLECTION_DATE+long+lat, 
                                   data = GAMA, FUN = mean, na.rm = TRUE)
#takes maximum for each well by year
GAMAPost2010Max <- aggregate(results ~ well.ID + GM_SAMP_COLLECTION_DATE+long+lat, 
                               data = GAMA, FUN = max, na.rm = TRUE)

#AVERAGE now each well 
GAMAPost2010Means_v2 <-aggregate(results ~ well.ID+long+lat,
                                    data = GAMAPost2010Means, FUN = mean, na.rm = TRUE)

#Take max  now for  each well
GAMAPost2010Max_v2 <-aggregate(results ~ well.ID+long+lat,
                                 data = GAMAPost2010Means, FUN = max, na.rm = TRUE)

#write the final int datasets
write.csv(GAMAPost2010Means_v2, "GAMA_SCV_Mean.csv")

#write the Max dataset
write.csv(GAMAPost2010Max_v2, "GAMA_SCV_Max.csv")


#Join to CV-SALTS 2023 Data
#set working directory 
setwd("~/Google Drive/Shared drives/CentralValleyWater/02_Data/01_Well_Data/CVSALTS_2023MZIPData")
#Chowchilla 
ChowWell <-read.csv("Chowchilla/ChowchillaWellCVSALTS.csv")
ChowNitrate <-read.csv("Chowchilla/ChowchillaNitrateCVSALTS.csv")
intersect(names(ChowWell),
          names(ChowNitrate))
#names 
Chow_All <- merge(ChowNitrate,
                  ChowWell,
                  by.x = "MODIFIED_GM_WELL_ID",
                  by.y = "MODIFIED_GM_WELL_ID",
                  all.x = T)

Chow_All$date <-as.Date(Chow_All$DATE_NUMERICAL,origin = "1899-12-30")
Chow_All<-subset(Chow_All, GM_DATASET_NAME == "MZ_Domestic")

write.csv(Chow_All, "Chow_ALlWellData.csv")
#Turlock
TurWell <-read.csv("Turlock/TurlockWellInfo.csv")
TurNitrate <-read.csv("Turlock/TurlockNitrateInfo.csv")
#names
Tur_All <- merge(TurNitrate,
                  TurWell,
                  by.x = "MODIFIED_GM_WELL_ID",
                  by.y = "MODIFIED_GM_WELL_ID",
                  all.x = T)

Tur_All$date <-as.Date(Tur_All$GM_SAMP_COLLECTION_DATE,format ='%m/%d/%Y' )
Turshallow <-subset(Tur_All, DEPTH_ZONE == "Upper")
Tur_All <-subset(TurWell, GM_DATA_SOURCE == "VWC")

TurUDates <- aggregate(GM_RESULT ~ MODIFIED_GM_WELL_ID + date, 
                       data = Turshallow, FUN = mean, na.rm = TRUE)

TurUnquewells <-merge(TurUDates,
                      TurWell,
                      by.x = "MODIFIED_GM_WELL_ID",
                      by.y = "MODIFIED_GM_WELL_ID",
                      all.x = T)
summary(TurUnquewells$GM_WELL_DEPTH_FT)
Count <-summarise(group_by(TurUnquewells, GM_WELL_CATEGORY), count =n())
summary(TurUnquewells$GM_WELL_CATEGORY)

write.csv(Tur_All, "TurMZIPWells.csv")
#Modesto
ModWell <-read.csv("Modesto/ModestoWellInfo.csv")
ModNitrate <-read.csv("Modesto/ModestoNitrateInfor.csv")
#names
Mod_All <- merge(ModNitrate,
                 ModWell,
                 by.x = "MODIFIED_GM_WELL_ID",
                 by.y = "MODIFIED_GM_WELL_ID",
                 all.x = T)

Mod_All$date <-as.Date(Mod_All$GM_SAMP_COLLECTION_DATE,format ='%m/%d/%Y' )
Mod_All <-subset(ModWell, GM_DATA_SOURCE == "VWC")
Modshallow <-subset(Mod_All, DEPTH_ZONE == "Upper")

#for counting observtaions with well depth data ###
ModUDates <- aggregate(GM_RESULT ~ MODIFIED_GM_WELL_ID + date, 
                                 data = Modshallow, FUN = mean, na.rm = TRUE)

ModUnquewells <-merge(ModUDates,
                      ModWell,
                      by.x = "MODIFIED_GM_WELL_ID",
                      by.y = "MODIFIED_GM_WELL_ID",
                      all.x = T)
summary(ModUnquewells$GM_WELL_DEPTH_FT)
CountM <-summarise(group_by(ModUnquewells, GM_WELL_CATEGORY), count =n())
AllVWC <- rbind(ModUnquewells,TurUnquewells)
CountVWC <-summarise(group_by(AllVWC, GM_WELL_CATEGORY), count =n())
summary(AllVWC$GM_WELL_DEPTH_FT)


VWCWells <-aggregate(GM_RESULT ~ MODIFIED_GM_WELL_ID,
                     data = AllVWC, FUN = mean, na.rm = TRUE)
Data <-subset(VWCWells1, GM_WELL_DEPTH_FT == 0)
VWCWells2<-left_join(AllVWC, VWCWells,by = "MODIFIED_GM_WELL_ID")
                
                by.x = "MODIFIED_GM_WELL_ID",
                by.y = "MODIFIED_GM_WELL_ID",
                all.x = T)
summary(VWCWells1$GM_WELL_DEPTH_FT)
write.csv(VWCWells1, "wellcount.csv")
###End


#Kaweah
KWAWell <-read.csv("Kaweah/Kaweah_Wellinfo.csv")
KWANitrate <-read.csv("Kaweah/Kaweah_Nitrateinfo.csv")
intersect(names(KWAWell),
          names(KWANitrate))

KWA_All <- merge(KWANitrate,
                 KWAWell,
                 by.x = "MODIFIED_GM_WELL_ID",
                 by.y = "MODIFIED_GM_WELL_ID",
                 all.x = T)
KWA_All$date <-as.Date(KWA_All$GM_SAMP_COLLECTION_DATE,format ='%m/%d/%Y' )
KWA_All <-subset(KWA_All, GM_DATA_SOURCE == "KWA")
#Write complete CSV
write.csv(KWA_All, "KWA_ALlWellData.csv")

#Kaweah
KawWell <-read.csv("Kaweah/Kaweah_Wellinfo.csv")
KawNitrate <-read.csv("Kaweah/Kaweah_Nitrateinfo.csv")
intersect(names(KawWell),
          names(KawNitrate))
#names 
Kaweah_All <- merge(KawNitrate,
                    KawWell,
                    by.x = "MODIFIED_GM_WELL_ID",
                    by.y = "MODIFIED_GM_WELL_ID",
                    all.x = T)
Kaweah_All$date <-as.Date(Kaweah_All$DATE_NUMERICAL,origin = "1899-12-30")
Kaweah_All <-subset(Kaweah_All, GM_DATA_SOURCE == "KWF")
write.csv(Kaweah_All, "Kaweah_ALlWellData.csv")
#Tulare
TulWell <- read.csv("Tule/TULEMZIP.csv")
TulWell$date <-as.Date(TulWell$Sample_Date,format ='%m/%d/%y' )
TulWell <-subset(TulWell, Data.Category == "TBMZ Dellavalle")
write.csv(TulWell, "Tulare_ALlWellData.csv")






#UpperChow <- subset(Chow_All, DEPTH_ZONE == "Upper") #get only wells in upper basin 
#format date. I believe this is the issue
#UpperChowPost2000 <-subset(UpperChow, date >= "1999-09-30")
#UpperChowPost2010 <-subset(UpperChow, date >="2009-09-30")


